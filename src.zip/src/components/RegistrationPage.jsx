import React, { useState } from 'react';
import axios from 'axios';
import { Slide, toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import '../styles/RegistrationPage.css'; // Custom CSS file for additional styling

const RegistrationPage = () => {
    const [email, setEmail] = useState("");
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();

    const notify = (message, type) => {
        const options = {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            theme: "colored",
            transition: Slide,
        };
        type === "success" ? toast.success(message, options) :
        type === "warning" ? toast.warning(message, options) :
        toast.error(message, options);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post("http://localhost:8081/api/user/register", { email, username, password });
            notify("Registered Successfully", "success");
            navigate("/login");
        } catch (error) {
            if (error.response && error.response.status === 409) {
                notify("User already exists with this email", "warning");
            } else {
                notify("Error while registering...", "error");
            }
        }
    };

    return (
        <div className="registration-bg d-flex align-items-center justify-content-center">
            <div className="card shadow-lg p-4 rounded registration-card">
                <h1 className="text-center mb-4 text-primary">REGISTER</h1>
                <form onSubmit={handleSubmit}>
                    <div className="form-group mb-3">
                        <label htmlFor="emailInput" className="form-label">Email Address</label>
                        <input
                            type="email"
                            className="form-control"
                            id="emailInput"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                        />
                    </div>
                    <div className="form-group mb-3">
                        <label htmlFor="usernameInput" className="form-label">Username</label>
                        <input
                            type="text"
                            className="form-control"
                            id="usernameInput"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                        />
                    </div>
                    <div className="form-group mb-4">
                        <label htmlFor="passwordInput" className="form-label">Password</label>
                        <input
                            type="password"
                            className="form-control"
                            id="passwordInput"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                        />
                    </div>
                    <button type="submit" className="btn btn-success w-100 mb-3">Register</button>
                    <div className="text-center">
                        <button
                            type="button"
                            className="btn btn-link text-decoration-none"
                            onClick={() => navigate("/login")}
                        >
                            Already have an account? Login
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default RegistrationPage;
