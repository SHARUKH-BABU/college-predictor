import React from 'react';

const HomePage = () => {
    return (
        <div className="container mt-5">
            {/* Header */}
            <header className="text-center mb-5">
                <h1 className="display-4">Welcome to Sharukh's Portfolio</h1>
                <p className="lead">Full Stack MERN Developer</p>
            </header>

            {/* About Me Section */}
            <section className="mb-5">
                <h2 className="h4">About Me</h2>
                <p>
                    Hello! I'm Sharukh, a Full Stack MERN Developer with experience in creating dynamic web applications.
                    I specialize in JavaScript, React, Node.js, Express.js, and MongoDB, and I’m passionate about building efficient, scalable solutions.
                </p>
            </section>

            {/* Projects Section */}
            <section className="mb-5">
                <h2 className="h4">Projects</h2>
                <ul className="list-unstyled">
                    <li>
                        <a href="https://buy-bazaar.onrender.com/" target="_blank" rel="noopener noreferrer" className="text-primary">
                            BuyBazaar E-commerce App
                        </a>
                    </li>
                    <li>
                        <a href="https://portfolio-omega-khaki-89.vercel.app/" target="_blank" rel="noopener noreferrer" className="text-primary">
                            My Portfolio Site
                        </a>
                    </li>
                </ul>
            </section>

            {/* Contact Me Section */}
            <section>
                <h2 className="h4">Contact Me</h2>
                <p>Feel free to reach out for collaboration or project opportunities:</p>
                <ul className="list-unstyled">
                    <li><strong>Email:</strong> sharukhbabu2004@gmail.com</li>
                    <li><strong>Phone:</strong> +91 6301270325</li>
                    <li>
                        <strong>LinkedIn:</strong> 
                        <a href="https://www.linkedin.com/in/shaik-sharukhbabu-80a52a281/" target="_blank" rel="noopener noreferrer" className="text-primary">
                            SHAIK SHARUKHBABU
                        </a>
                    </li>
                </ul>
            </section>
        </div>
    );
};

export default HomePage;
